package controller;

import dao.Usuario;
import factory.ConnectionFactory;
import java.sql.Connection;
import model.UsuarioModel;

public class UsuarioController {

    private Usuario usuario;

    public UsuarioController(Usuario usu) {
        this.usuario = usu;
    }

    public Usuario login() {
        Connection conexao = ConnectionFactory.getConnection();{
        UsuarioModel model = new UsuarioModel(conexao, this.usuario);
        Usuario resposta = model.login();
        return resposta;
        }
    }
}
