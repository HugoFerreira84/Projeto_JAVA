
package factory;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
    public static Connection getConnection(){
        Connection conexao = null;
        try {
            conexao = DriverManager.getConnection("jdbc:mysql://localhost/db3003","root","");
        } catch (Exception e) {
            System.out.println("Erro ao conectar com o banco de dados.");
            System.out.println(e.getMessage());
        }
        return conexao;
    }
}
