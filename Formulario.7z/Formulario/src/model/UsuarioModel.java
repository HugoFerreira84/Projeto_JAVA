package model;

import dao.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsuarioModel {

    private Connection conexao;
    private Usuario usuario;

    public UsuarioModel(Connection con, Usuario usu) {
        this.conexao = con;
        this.usuario = usu;
    }
    public Usuario login() {
        Usuario usu = new Usuario();
        try {
            String sql = "SELECT * FROM tbl_login WHERE login = ? AND senha = ?";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            stm.setString(1, this.usuario.getLogin());
            stm.setString(2, this.usuario.getSenha());
            ResultSet rs = stm.executeQuery();
            while(rs.next()){
                usu.setId(rs.getInt("id"));
                usu.setLogin(rs.getString("login"));
                usu.setSenha(rs.getString("senha"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao fazer o login");
            System.out.println(e.getMessage());
        }
        return usu;
    }

}
